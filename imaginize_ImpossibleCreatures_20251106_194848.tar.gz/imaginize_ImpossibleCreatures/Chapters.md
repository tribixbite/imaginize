# Chapters - Impossible Creatures

## Visual Scenes by Chapter

Each scene includes exact quotes from the source text for illustration reference.

---

### The Beginning

#### Scene 1

**Pages:** 7-7 (Lines 6-6)

**Source Text:**
> It was a very fine day, until something tried to eat him. It was a black doglike creature, but it was not like any dog he had ever seen. It had teeth as long as his forearm and claws that could tear apart an oak tree. It says, therefore, a great deal in Christopher Forrester’s favor that he refused—with speed and cunning and courage—to be eaten.

**Visual Elements:** A black doglike creature with long teeth and claws. The claws can tear apart an oak tree. Christopher Forrester refusing to be eaten.

---

### The Beginning, Elsewhere

#### Scene 1

**Pages:** 8-8 (Lines 7-7)

**Source Text:**
> Mal had returned home from her journey, flying back from the forest with arms outstretched and coat flapping, buffeted by the wind. Mal Arvorian could fly only when the wind blew. The weather that day was perfect—a westerly breeze that smelled of the sea—and she was sky spinning, twisting in the cold air. Her flying coat was thick and too big for her, and she wore it with the sleeves rolled up four times. When the wind was up—it didn’t need to be strong, but some wind was necessary—she could catch at the corners and open it, like wings, and feel the breeze lift her off her feet.

**Visual Elements:** Mal flying back from the forest with arms outstretched and coat flapping in the wind. She is sky spinning and twisting in the cold air. Her flying coat is thick, too big, and the sleeves are rolled up four times. She can catch the corners of the coat and open it, like wings.

---

### Arrival

#### Scene 1

**Pages:** 9-11 (Lines 8-8)

**Source Text:**
> A squirrel leaped onto the bench and watched him. Slowly it edged closer, quivering, until its whiskers were touching his knee. It was joined by another, and then another, until there were seven of them, clustering around his feet. A woman waiting at the taxi rank turned to stare. “How’s he doing that then?” she said to the man next to her. One squirrel darted to crouch on the toe of Christopher’s shoe. Christopher laughed, and the squirrel ran up his shinbone to his knee.

**Visual Elements:** Christopher sitting on a bench outside a ferry terminal. A squirrel leaps onto the bench. The squirrel edges closer and touches his knee with its whiskers. More squirrels arrive, seven in total, clustering around his feet. A woman at a taxi rank stares at Christopher. A squirrel crouches on the toe of Christopher's shoe, then runs up his leg to his knee. Christopher laughs.

---

### Arrival, Elsewhere

#### Scene 1

**Pages:** 12-15 (Lines 9-9)

**Source Text:**
> That spring morning she had flown over the sea with her bare feet skimming the water, her boots in her pockets, the ocean spray flecking her ankles, laughing with the speed and joy of it. The murderer had watched her and smiled an unlovely smile. Mal was forbidden to fly anywhere except around the garden or across the fields: her great-aunt Leonor would have been horrified had she known how far Mal went.

**Visual Elements:** Spring morning. Mal flies over the sea with bare feet skimming the water. She has her boots in her pockets. Ocean spray flecks her ankles. She is laughing. The murderer watches her and smiles an unlovely smile. Mal is forbidden to fly far from her garden and fields.

---

### Frank Aureate

#### Scene 1

**Pages:** 16-17 (Lines 10-10)

**Source Text:**
> A car horn hooted, and the squirrels scattered. A battered Ford drew up next to Christopher’s bench, and a man in his seventies leaned out. “Christopher? Is that you?” On top of the roof of the car were four seagulls. “They follow me around whenever I come to town,” said Frank Aureate, gesturing to the gulls as Christopher approached. His voice was deep, Scottish.

**Visual Elements:** A car horn, squirrels scattering, a battered Ford car pulling up next to a bench. An elderly man in his seventies leaning out of the car. Four seagulls on top of the car roof. Christopher approaching the car.

---

#### Scene 2

**Pages:** 16-17 (Lines 10-10)

**Source Text:**
> But the sandwiches were excellent, on thick fresh bread, and the view outside the car grew greener every minute. “We’ve no neighbors; the next nearest house is a good twenty-one miles away. It’s a long way yet,” said Frank Aureate. “Sleep, if you want to.” But Christopher didn’t sleep: of course he didn’t. He watched. Eventually the houses at the roadside stopped altogether, and they were driving along mountain roads, past lochs and heather.

**Visual Elements:** Thick sandwiches on fresh bread. A view from inside a car, becoming increasingly green. Houses disappearing from the roadside. A drive along mountain roads, past lochs and heather.

---

#### Scene 3

**Pages:** 16-17 (Lines 10-10)

**Source Text:**
> Eventually the houses at the roadside stopped altogether, and they were driving along mountain roads, past lochs and heather. The way grew steeper and the earth darker, a peaty black dotted with gorse. The air began to smell different—richer, and deeper, and wilder.

**Visual Elements:** Houses gone, driving on mountain roads, past lochs and heather. The road is steeper, the earth is darker, peaty black with gorse.

---

